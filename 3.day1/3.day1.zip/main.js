let a=0
function enterkey() {
        if (window.event.keyCode == 37) {
            console.log('left');
            document.getElementById("img").src = "./막걸리흔들기2.png";
        }
        if(window.event.keyCode==39){
           console.log('right')
           document.getElementById("img").src = "./막걸리흔들기1.png";
        }
        a=a+1
    }
function pop(){
    if(a>10){
        console.log('pop');
        document.getElementById("img").src = "./막걸리터짐.png";
    }

}
